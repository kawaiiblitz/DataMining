geyser.dat <- read.table(file="Ruta_del_archivo/geyser.txt", dec=",",sep=";", header=F, 
                         col.names  = c("duracion", "intervalo"))

attach(geyser.dat)

plot(duracion, intervalo)

abline(lm(intervalo ~ duracion))

geyser.lm = lm (intervalo ~ duracion)

summary(geyser.lm)

geyser.lm$fitted
geyser.lm$resid
geyser.lm$coef

plot(geyser.lm,which=1)