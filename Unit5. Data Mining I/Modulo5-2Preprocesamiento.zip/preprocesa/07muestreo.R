data("iris")

library(car)

iris

scatterplotMatrix(iris,diagonal="histogram",smooth = FALSE)

muestra.sin <- sample(1:nrow(iris),20) #Se en este caso es sin remplazo

muestra.sin

muestra.con <- sample(1:nrow(iris),20,replace = TRUE)

muestra.con

s.sin <- iris[muestra.sin,]
s.con <- iris[muestra.con,]

scatterplotMatrix(s.sin,diagonal="histogram",smooth = FALSE)
scatterplotMatrix(s.con,diagonal="histogram",smooth = FALSE)

muestra.sin <- sample(1:nrow(iris),nrow(iris)*.2)

muestra.sin

#Instalar el paquete sampling, si es que a�n no se cuenta con �l.
install.packages("sampling")

library(sampling)

muestra2 <- strata(iris,stratanames = "Species", size = c(7,7,7),method = "srswor")

#Los m�todos disponibles son:
#simple random sampling without replacement (srswor)
#simple random sampling with replacement (srswr)
#Poisson sampling (poisson)
#systematic sampling (systematic)
#Si no se indica el m�todo, por omisi�n se toma "srswor"

muestra2

s <- iris[muestra2$ID_unit,]

scatterplotMatrix(s,diagonal="histogram",smooth = FALSE)

porcentaje <- sample(1:nrow(iris), 0.2*nrow(iris),replace = TRUE)
porcentaje