data("iris")
library(car)
iris

########### AGREGACI�N ##########
agrega <- aggregate(. ~ Species, data = iris, FUN = mean)

agrega

agrega <- aggregate(. ~ Species, data = iris, FUN = median)

agrega

scatterplotMatrix(agrega,diagonal="histogram",smooth = FALSE)

########### NORMALIZACI�N ##########

##### Z- SCORE #####
iris[1:4]

summary(iris[1:4])

scatterplotMatrix(iris[1:4],diagonal="histogram",smooth = FALSE)

iris.normalizados <- scale(iris[1:4])

head(iris.normalizados)

summary(iris.normalizados)

scatterplotMatrix(iris.normalizados,diagonal="histogram",smooth = FALSE)

########## MIN-MAX ##########
min.max <- function(x) {
  return (((x - min(x)) / (max(x) - min(x))*(2))-1)
}

normalizados <- as.data.frame(lapply(iris[1:4],min.max))

summary(normalizados)

scatterplotMatrix(normalizados,diagonal="histogram",smooth = FALSE)

########### DISCRETIZACI�N ##########

plot(iris$Petal.Width, 1:150, ylab="ID de la muestra")

hist(iris$Petal.Width,col="lightblue")

ancho <-cut(iris$Petal.Width, breaks=3)

table(ancho)

hist(iris$Petal.Width,col="green",main = "Discretizaci�n: Igual ancho",
     sub = "L�neas en azul son los l�mites")
abline(v = ancho,col = "blue")

########## DISCRETIZE #########

#Instalamos el paquete en caso de no tenerlo
install.packages("arules")

library(arules)

#El m�todo discretize convierte una variable continua en una variable categ�rica.
#Los m�todos disponibles son:
#"interval" (equal interval width)
#"frequency" (equal frequency)
#"cluster" (k-means clustering)
#"fixed" (categories specifies interval boundaries)

#####Cl�ster#####
cluster <- discretize(iris$Petal.Width, method="cluster", categories=3,onlycuts=TRUE)
table(cluster)

hist(iris$Petal.Width,col="green",main = "Discretizaci�n: cl�ster",
     sub = "L�neas en azul son los l�mites")
abline(v = cluster,col = "blue")

#####Frecuencia#####
frec <- discretize(iris$Petal.Width, method="frequency", categories=3,onlycuts=TRUE)
table(frec)

hist(iris$Petal.Width,col="green",main = "Discretizaci�n: Frecuencia",
     sub = "L�neas en azul son los l�mites")
abline(v = frec,col = "blue")

#####Intervalo#####
interval <- discretize(iris$Petal.Width, method="interval", categories=3,onlycuts=TRUE)
table(interval)

hist(iris$Petal.Width,col="green",main = "Discretizaci�n: Frecuencia",
     sub = "L�neas en azul son los l�mites")
abline(v = interval,col = "blue")