library(MASS)


tabla <- table(survey$Smoke,survey$Exer)
tabla

chisq.test(tabla)