#Instalamos los siguientes paquetes (en caso de no tenerlos ya):
install.packages("HSAUR")
install.packages("car")

data("heptathlon", package = "HSAUR")

heptathlon

summary(heptathlon)

library(car)

score <- which(colnames(heptathlon)=="score")

scatterplotMatrix(heptathlon[,-score],diagonal="histogram")

heptathlon$hurdles <- max(heptathlon$hurdles)-heptathlon$hurdles
heptathlon$run200m <- max(heptathlon$run200m)-heptathlon$run200m
heptathlon$run800m <- max(heptathlon$run800m)-heptathlon$run800m

scatterplotMatrix(heptathlon[,-score],diagonal="histogram",smooth = FALSE)

round(cor(heptathlon[,-score]),2)

heptatlon_pca <-prcomp(heptatlon[,-score],scale = TRUE)

heptatlon_pca

summary(heptatlon_pca)

c1 <- heptatlon_pca$rotation[,1]
c1

plot(heptatlon_pca)

biplot(heptatlon_pca,col = c("red","blue"),cex=0.5)

cor(heptatlon$score,heptatlon_pca$x[,1])

plot(heptatlon$score,heptatlon_pca$x[,1])