data("iris")

names(iris)

attach(iris)

table(Species)

#Instalamos la biblioteca (solo si no la tenemos)
install.packages("ggplot2")

library(ggplot2)

qplot(Petal.Width,Sepal.Width, data = iris, colour = Species, size = I(5))+theme_grey(base_size = 18)+ggtitle("Dispersi�n Iris")+theme(plot.title = element_text(hjust = 0.5))

boxplot(Sepal.Length,main="Boxplot Sepal.Length")
boxplot(Sepal.Length~Species,ylab="Sepal.Length",main="Boxplot Species",cex.lab=1.5, cex.axis=1.5, cex.main=1.5, cex.sub=1.5)
boxplot(x=iris[,1:4],main="Boxplots Iris",cex.lab=1.5, cex.axis=1.5, cex.main=1.5, cex.sub=1.5)
