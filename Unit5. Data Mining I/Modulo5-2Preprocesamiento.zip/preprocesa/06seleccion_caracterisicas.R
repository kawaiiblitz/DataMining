#Instalamos los siguientes paquetes, en caso de no contar con ellos.
install.packages("mlbench")
install.packages("FSelector")

data("Zoo",package="mlbench")

Zoo

library(FSelector)

pesos <- chi.squared(type~.,data=Zoo)

pesos

str(pesos)

orden <- order(pesos$attr_importance)
dotchart(pesos$attr_importance[orden],labels=rownames(pesos)[orden],xlab="Importancia")

subconjunto <- cutoff.k(pesos,5)

subconjunto

#Podemos utilizar cualquiera de las siguientes funciones
#oneR(type~.,data=Zoo)
#gain.ratio(type~.,data=Zoo)
#information.gain(type~.,data=Zoo)